# 四步反馈回路

Atelier 自制参数化 HyperFrames 模板。

修改 default.json 后，在此目录运行：

```sh
npx hyperframes check .
npx hyperframes render . --variables-file default.json --strict-variables --output result.mp4
```

默认数字仅为演示，替换为已确认的材料。形式参考 https://github.com/nutllwhy/hyperframes-motion-library，不含该仓库源码、文案或媒体。模板代码见 LICENSE，GSAP 保留其文件头许可。
